# AST data

Inputs for the code in the `ast-telemetry` repository. Point `AST_DATA` at this directory.

| Path | Content | Source | Licence |
|---|---|---|---|
| `sar/{hiker,elderly,child}.json` | SAR interview corpora: schema, importance, dependencies, question bank, answers, expert resolution scores, scripted regimes S1-S3 | this work | CC BY 4.0 |
| `sar/llm_scores/{corpus}.json` | per-turn scores of five LLMs, their ensemble mean and the expert scores | this work (Ollama: gemma3:12b, ministral-3:14b, gemma2, qwen3, llama3.1; temperature 0) | CC BY 4.0 |
| `maptask/annotations.json` | 27 HCRC Map Task dialogues as instruction-response pairs with manual landmark-resolution scores | transcripts: HCRC Map Task Corpus (NXT release); scores: this work | CC BY 4.0 |
| `multiwoz/sessions.json` | 40 train-booking dialogues with belief-state slot scores | MultiWOZ 2.4, built by `experiments/prepare_multiwoz.py` (seed 42) | MIT |
| `annomi/annotations.json` | 20 AnnoMI counselling sessions (10 high, 10 low quality) with manual therapy-construct scores | transcripts: AnnoMI; scores: this work | see note |
| `boir/data{1,3}/` | BOIR intent-inference logs (path, angle, posterior-change files) for scenarios S1 and S3 | BOIR intent estimator (cited in the paper) | CC BY 4.0 |
| `embeddings/{sar,maptask,multiwoz,annomi}.npz` | `texts` and `vectors` (qwen3-embedding, 4096 dimensions) for every response the monitor reads | this work, `tools/embed.py` | CC BY 4.0 |

AnnoMI is distributed without an explicit licence; cite Wu et al. (2022) when using the AnnoMI transcripts.

`MANIFEST.sha256` lists the checksum of every file (`sha256sum -c MANIFEST.sha256`).
